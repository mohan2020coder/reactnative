export const articles_url = 'https://newsapi.org/v2/top-headlines';
export const country_code = 'in';
export const category = 'general';
export const _api_key = 'YOUR_API_KEY';
