import React from 'react'

function InputScreen() {
  return (
    <div>InputScreen</div>
  )
}

export default InputScreen