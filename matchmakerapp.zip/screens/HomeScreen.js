import React, { useRef } from "react";
import {
  SafeAreaView,
  ScrollView,
  Text,
  StyleSheet,
  View,
  TouchableOpacity,
  ImageBackground,
  Animated,
  useWindowDimensions
} from "react-native";

const images = new Array(6).fill('https://images.unsplash.com/photo-1556740749-887f6717d7e4');
const HomeScreen = ({ navigation }) => {
  const scrollX = useRef(new Animated.Value(0)).current;

  const { width: windowWidth } = useWindowDimensions();
  return (
    <SafeAreaView
      style={{ flex: 1, justifyContent: 'center', alignItems: 'center', backgroundColor: 'rgba(0,200,0, 0.5)' }}>
      <View style={styles.scrollContainer}>
        <ScrollView
          horizontal={true}
          pagingEnabled
          showsHorizontalScrollIndicator={false}
          onScroll={Animated.event([
            {
              nativeEvent: {
                contentOffset: {
                  x: scrollX
                }
              }
            }
          ], { useNativeDriver: false })}
          scrollEventThrottle={1}
        >
          {images.map((image, imageIndex) => {
            return (
              <View
                style={{ width: windowWidth, height: 400 }}
                key={imageIndex}
              >
                <ImageBackground source={{ uri: image }} style={styles.card}>


                </ImageBackground>
                <View style={styles.textContainer}>
                  <TouchableOpacity
                    style={styles.btn}
                    onPress={() => navigation.replace('InputScreen')}>
                    <Text style={{ fontWeight: 'bold', fontSize: 15, color: "white" }}>
                      View Profile
                    </Text>

                  </TouchableOpacity>
                </View>
                <View style={[styles.card1, styles.shadowProp]}>
                  <View>
                    <Text style={styles.heading}>
                      name of person
                    </Text>
                  </View>
                  <Text>
                    Using the elevation style prop to apply box-shadow for iOS devices
                  </Text>
                </View>

              </View>

            );
          })}
        </ScrollView>
        <View style={styles.indicatorContainer}>
          {images.map((image, imageIndex) => {
            const width = scrollX.interpolate({
              inputRange: [
                windowWidth * (imageIndex - 1),
                windowWidth * imageIndex,
                windowWidth * (imageIndex + 1)
              ],
              outputRange: [8, 16, 8],
              extrapolate: "clamp"
            });
            return (
              <Animated.View
                key={imageIndex}
                style={[styles.normalDot, { width }]}
              />
            );
          })}
        </View>

      </View>
    </SafeAreaView>
  );
};


const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: "center",
    justifyContent: "center"
  },
  scrollContainer: {
    height: 500,
    alignItems: "center",
    justifyContent: "center"
  },
  card: {
    flex: 1,
    marginVertical: 4,
    marginHorizontal: 40,
    borderRadius: 20,
    height: 500,
    shadowColor: '#171717',
    shadowOffset: { width: -2, height: 4 },
    shadowOpacity: 0.2,
    shadowRadius: 3,
    overflow: "hidden",
    alignItems: "center",
    justifyContent: "center"
  },
  textContainer: {
    backgroundColor: "rgba(0,200,0, 0.5)",
    paddingHorizontal: 24,
    paddingVertical: 8,
    width: 200,
    alignItems: "center",
    borderRadius: 5,
    marginTop: -300
  },
  infoText: {
    color: "white",
    fontSize: 16,
    fontWeight: "bold"
  },
  normalDot: {
    height: 8,
    width: 8,
    borderRadius: 4,
    backgroundColor: "white",
    marginHorizontal: 5
  },
  indicatorContainer: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    marginTop: 20,
  },
  btn: {
    height: 30,
    marginTop: 10,
    alignItems: "center"
  },
  heading: {
    fontSize: 18,
    fontWeight: '600',
    marginBottom: 13,
  },
  card1: {
    backgroundColor: 'white',
    color: "gray",
    borderRadius: 8,
    paddingVertical: 20,
    paddingHorizontal: 25,
    width: '92%',
    marginVertical: 20,
  },
  elevation: {
    elevation: 20,
    shadowColor: '#52006A',
  },

});
export default HomeScreen;