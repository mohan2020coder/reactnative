import { Image, View , StyleSheet, StatusBar, Alert} from 'react-native';
import { Button, Icon } from 'react-native-elements';
import AsyncStorage from '@react-native-async-storage/async-storage';

import Onboarding from 'react-native-onboarding-swiper';

const Square = ({ isLight, selected }) => {
  let backgroundColor;
  if (isLight) {
    backgroundColor = selected ? 'rgba(0, 0, 0, 0.8)' : 'rgba(0, 0, 233, 0.3)';
  } else {
    backgroundColor = selected ? '#fff' : 'rgba(255, 255, 255, 0.5)';
  }
  return (
    <View
      style={{
        width: 8,
        height: 8,
        marginHorizontal: 2,
        backgroundColor,
      }}
    />
  );
};

const backgroundColor = isLight => (isLight ? 'blue' : 'lightblue');
const color = isLight => backgroundColor(!isLight);

const Done = ({ isLight, ...props }) => (
  <Button
    title={'Done'}
    buttonStyle={{
      backgroundColor: backgroundColor(isLight),
    }}
    containerViewStyle={{
      
      marginHorizontal: 90,
      width: 50,
      backgroundColor: backgroundColor(isLight),
    }}
    textStyle={{ color: color(isLight) }}
    {...props}
  />
);

const Skip = ({ isLight, skipLabel, ...props }) => (
  <Button
    title={'Skip'}
    buttonStyle={{
      backgroundColor: backgroundColor(isLight),
    }}
    containerViewStyle={{
      marginVertical: 30,
      width: 10,
    }}
    textStyle={{ color: color(isLight) }}
    {...props}
  >
    {skipLabel}
  </Button>
);

const Next = ({ isLight, ...props }) => (
  <Button
    title={'Next'}
    buttonStyle={{
      backgroundColor: backgroundColor(isLight),
    }}
    containerViewStyle={{
      marginHorizontal:20,
      marginLeft:-80,
      width: 50,
      backgroundColor: backgroundColor(isLight),
    }}
    textStyle={{ color: color(isLight) }}
    {...props}
  />
);

const completeOnboarding = async ()=>{
  await AsyncStorage.setItem('hasOnboard',JSON.stringify({
    hasOnboarded:true
  }));
  props.navigation.navigate('Home')
};

const OnboardingScreen2 = () => (

 
  <Onboarding
    DotComponent={Square}
    NextButtonComponent={Next}
    SkipButtonComponent={Skip}
    DoneButtonComponent={Done}
    bottomBarHighlight={true}
    controlStatusBar={false}
    onDone={completeOnboarding}
    onSkip={completeOnboarding}
    titleStyles={{ color: 'white', marginLeft:100 }} 
    subTitleStyles={{ color: 'white', marginLeft:100 }} // set default color for the title
    pages={[
      {
        backgroundColor: 'green',
        image: <Image source={require('../assets/pair.png')} style={styles.img} />,
        title: 'Welcome to MatchMaker',
        subtitle: 'Find your Partner with MatchMaker, \n   Marriage, ultimately, is the practice of becoming passionate friends.',
        titleStyles: { color: 'yellow' }, // overwrite default color
      },
      {
        backgroundColor: 'lightblue',
        image: <Image source={require('../assets/star.png')} style={styles.img1} />,
        title: 'Star profile details',
        subtitle: 'Some of best profiles list.',
      },
      {
        backgroundColor: 'brown',
        image: <Image source={require('../assets/like.png')} style={styles.img2} />,
        title: '   Like the Profile you like',
        subtitle: "    Beautiful, Now we have like feature for you?",
      },
      {
        title: "That's Enough",
        subtitle: (
          <Button
            title={'Get Started'}
            containerViewStyle={{ marginTop: 20}}
            backgroundColor={'white'}
            borderRadius={5}
            textStyle={{ color: '#003c8f' }}
            onPress={() => {
              Alert.alert('done');
              StatusBar.setBarStyle('default');
              completeOnboarding;
            }}
          />
        ),
        backgroundColor: '#003c8f',
        image: (
          <Icon name="rocket" type="font-awesome" size={100} color="white" />
        ),
      },
    ]}
  />
);
const styles = StyleSheet.create({
  img: {
    marginBottom: 10,
    borderRadius: 50,
    width: 250,
    height: 250,
  },
  img1: {
    marginBottom: 10,
    borderRadius: 50,
    width: 280,
    height: 250,
    marginLeft:150
  },
  img2: {
    marginBottom: 10,
    borderRadius: 50,
    width: 300,
    height: 250,
    marginLeft:250
  }

});

export default OnboardingScreen2;