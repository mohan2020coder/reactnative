import { useRef, useEffect } from 'react';
import * as React from "react";
import { Box, Text, Heading, VStack, FormControl, Input, Link, Button, HStack, Center, NativeBaseProvider } from "native-base";
import { Animated, StyleSheet } from 'react-native';
import LottieView from 'lottie-react-native';


function LoginScreen({navigation}) {
  return (
    <NativeBaseProvider>
      <Center flex={1} px="3">
        <Example  navigation={navigation}/>
      </Center>
    </NativeBaseProvider>
  )
}

export default LoginScreen


const Example = ({navigation}) => {

  const fadeAnim = useRef(new Animated.Value(0)).current;

  const fadeIn = () => {
    // Will change fadeAnim value to 1 in 5 seconds
    Animated.timing(fadeAnim, {
      toValue: 1,
      duration: 1000,
      useNativeDriver: true
    }).start();
  };

  useEffect(() => {
    fadeIn();
  });

  return <Center w="100%">
   <LottieView source={require('../assets/partner.json')} autoPlay loop style={styles.anim}/> 
    <Box safeArea p="2" py="8" w="90%" maxW="290" h="40%">
      <Heading size="lg" fontWeight="500" color="coolGray.800" _dark={{
        color: "warmGray.50"
      }} style={{width:'100%'}}>
       MatchMaker
      </Heading>
      

      <VStack space={3} mt="5">
        <FormControl>
          <FormControl.Label>Email ID</FormControl.Label>
          <Input />
        </FormControl>
        
        <Button mt="2" colorScheme="indigo" >
          Change Password
        </Button>
       
        <HStack mt="6" justifyContent="center">
          <Text fontSize="sm" color="coolGray.600" _dark={{
            color: "warmGray.200"
          }}>
            Login with new password .{" "}
          </Text>
          <Link _text={{
            color: "indigo.500",
            fontWeight: "medium",
            fontSize: "sm"
          }} onPress={() => navigation.replace("LoginScreen")}>
           
          Login
       
          </Link>
        </HStack>
      </VStack>
    </Box>
  </Center>;
  
};

const styles = StyleSheet.create({
  anim:{
    flex: 1,
    marginTop:-220,
  },
  container: {
    flex: 1,
    alignItems: "center",
    justifyContent: "center"
  },
  fadingContainer: {
    padding: 20,
    marginBottom: 50,
    backgroundColor: "powderblue",
    color: "white"
  },
  fadingText: {
    fontSize: 28,
    color: "green"
  },
  oval: {
    width: '90%',
    height: 70,
    display: 'flex',
    justifyContent: 'center',
    marginLeft: 30,
    marginBottom: 10,
    padding: 20,
    borderRadius: 50,
    backgroundColor: "powderblue",
    transform: [{ scaleX: 2 }],
  },
  buttonRow: {
    flexBasis: 100,
    justifyContent: "space-evenly",
    marginVertical: 16
  }
});
