import theme, { COLORS, SIZES } from './theme';

export { theme, COLORS, SIZES };