const COLORS = {
  white: '#FFF',
  dark: '#000',
  light: '#f6f6f6',
  grey: '#A9A9A9',
  blue: '#5f82e6',
  red: 'red',
  tranparent: 'rgba(0,0,0,0)',
};

export default COLORS;
