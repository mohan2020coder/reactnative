import React from 'react'
import { View, Text } from 'react-native'

const MessagesScreen = () => {
  return (
    <View style={{flex:1,justifyContent:'center',alignItems:'center'}}>
      <Text>Messages Screen</Text>
    </View>
  )
}

export default MessagesScreen